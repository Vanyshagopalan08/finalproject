package com.example.psm;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class emergencyContact extends AppCompatActivity {
    private Button addmorebtn1, mainpage;
    private TextView txt1contact, te1,te2,te3,te4,te5,te6;
    DatabaseReference dref;
    String numbertxt2,contacttxt2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency_contact);
        //databaseReference= FirebaseDatabase.getInstance().getReference("Contacts");
        te1=findViewById(R.id.textView32);
        te2=findViewById(R.id.textView34);
        te3=findViewById(R.id.textView36);
        te4=findViewById(R.id.textView33);
        te5=findViewById(R.id.textView35);
        te6=findViewById(R.id.textView37);
        addmorebtn1 = findViewById(R.id.addlistbtn);
        txt1contact = findViewById(R.id.textviewctc);
        mainpage = findViewById(R.id.gotomain);

        setTitle("Emergency Contact");

        addmorebtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), addcontact.class));
            }
        });

        mainpage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Notification_initiate.class));
            }
        });

        dref = FirebaseDatabase.getInstance().getReference().child("Contacts Driver").child("Police");
        dref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String nameofcontactsRe1 = snapshot.child("nameofcontacts").getValue().toString();
                String numbersRe1 = snapshot.child("numbers").getValue().toString();
                te1.setText(nameofcontactsRe1);
                te4.setText(numbersRe1);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        dref = FirebaseDatabase.getInstance().getReference().child("Contacts Driver").child("Emergency Contacts");
        dref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String nameofcontactsRe2 = snapshot.child("nameofcontacts").getValue().toString();
                String numbersRe2 = snapshot.child("numbers").getValue().toString();
                te2.setText(nameofcontactsRe2);
                te5.setText(numbersRe2);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        dref = FirebaseDatabase.getInstance().getReference().child("Contacts Driver").child("Bomba");
        dref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String nameofcontactsRe3 = snapshot.child("nameofcontacts").getValue().toString();
                String numbersRe3 = snapshot.child("numbers").getValue().toString();
                te3.setText(nameofcontactsRe3);
                te6.setText(numbersRe3);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });













    }
}