package com.example.psm;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.pusher.pushnotifications.PushNotifications;

import java.util.ArrayList;

public class EmergencyContact_Relation extends AppCompatActivity {

    private Button addmorebtnrel,call1,call2,call3;
    private TextView txt1rel, texts0,texts9,texts8,texts7,texts6,texts5;
    DatabaseReference dref;
    String number2,contact2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency_contact__relation);

        addmorebtnrel = findViewById(R.id.button23);
        call1 = findViewById(R.id.buttoncal1);
        call2 = findViewById(R.id.button10);
        call3 = findViewById(R.id.button13);
        txt1rel = findViewById(R.id.textView22);
        texts0 = findViewById(R.id.textView24);
        texts9 = findViewById(R.id.textView25);
        texts8 = findViewById(R.id.textView26);
        texts7 = findViewById(R.id.textView28);
        texts6 = findViewById(R.id.textView29);
        texts5 = findViewById(R.id.textView30);


        setTitle("Emergency Contacts");



        dref = FirebaseDatabase.getInstance().getReference().child("Contacts Driver").child("Police");
        dref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String nameofcontactsa = snapshot.child("nameofcontacts").getValue().toString();
                String numbersb = snapshot.child("numbers").getValue().toString();
                texts8.setText(nameofcontactsa);
                texts8.setText(numbersb);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        dref = FirebaseDatabase.getInstance().getReference().child("Contacts Driver").child("Emergency Contacts");
        dref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String nameofcontactsc = snapshot.child("nameofcontacts").getValue().toString();
                String numbersd = snapshot.child("numbers").getValue().toString();
                texts0.setText(nameofcontactsc);
                texts0.setText(numbersd);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        dref = FirebaseDatabase.getInstance().getReference().child("Contacts Driver").child("Bomba");
        dref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String nameofcontactse = snapshot.child("nameofcontacts").getValue().toString();
                String numbersf = snapshot.child("numbers").getValue().toString();
                texts9.setText(nameofcontactse);
                texts9.setText(numbersf);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });




        addmorebtnrel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Notification_Relation.class));
                finish();
            }
        });

        call1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number=texts0.getText().toString();
                Intent callIntent = new Intent(Intent.ACTION_DIAL);
                callIntent.setData(Uri.parse("tel:"+number));
                startActivity(callIntent);


            }
        });

        call2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number2=texts8.getText().toString();
                Intent callIntent2 = new Intent(Intent.ACTION_DIAL);
                callIntent2.setData(Uri.parse("tel:"+number2));
                startActivity(callIntent2);

            }
        });

        call3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number3=texts9.getText().toString();
                Intent callIntent3 = new Intent(Intent.ACTION_DIAL);
                callIntent3.setData(Uri.parse("tel:"+number3));


                startActivity(callIntent3);

            }
        });












    }
}