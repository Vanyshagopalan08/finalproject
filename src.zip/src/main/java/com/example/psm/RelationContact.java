package com.example.psm;

public class RelationContact {
    String numbersRE,nameofcontactsRE;

    public RelationContact(String numbersRE, String nameofcontactsRE) {
        this.numbersRE = numbersRE;
        this.nameofcontactsRE = nameofcontactsRE;
    }

    public String getNumbersRE() {
        return numbersRE;
    }

    public void setNumbersRE(String numbersRE) {
        this.numbersRE = numbersRE;
    }

    public String getNameofcontactsRE() {
        return nameofcontactsRE;
    }

    public void setNameofcontactsRE(String nameofcontactsRE) {
        this.nameofcontactsRE = nameofcontactsRE;
    }
}
