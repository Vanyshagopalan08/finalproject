package com.example.psm;

public class Contact {
    String numbers, nameofcontacts;

    public Contact(String numbers, String nameofcontacts) {
        this.numbers = numbers;
        this.nameofcontacts = nameofcontacts;
    }

    public String getNumbers() {
        return numbers;
    }

    public void setNumbers(String numbers) {
        this.numbers = numbers;
    }

    public String getNameofcontacts() {
        return nameofcontacts;
    }

    public void setNameofcontacts(String nameofcontacts) {
        this.nameofcontacts = nameofcontacts;
    }
}


