package com.example.psm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.google.firebase.auth.FirebaseAuth;

public class Mainpage_Relation extends AppCompatActivity {
    private Button logins_R,registers_R;
    private ImageView logo2_R;
    private FirebaseAuth fAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainpage__relation);

        logins_R = findViewById(R.id.button15_R);
        registers_R = findViewById(R.id.button16_R);
        logo2_R = findViewById(R.id.imageView2_R);
        fAuth = FirebaseAuth.getInstance();

        setTitle("Safety App");

        logins_R.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Login_Relation.class));

            }
        });

        registers_R.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Register_Relation.class));
            }
        });



    }
}