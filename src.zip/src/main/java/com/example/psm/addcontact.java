package com.example.psm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class addcontact extends AppCompatActivity {
    private EditText HPnum, contactname;
    private Button addnum, in;
    private TextView pls;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    Contact contact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addcontact);

        HPnum = findViewById(R.id.editTextPhone2);
        contactname = findViewById(R.id.editTextTextPersonName2);
        addnum = findViewById(R.id.button3);
        pls = findViewById(R.id.textView7);
        in = findViewById(R.id.button7);

        setTitle("Add Emergency Contact");

        in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),emergencyContact.class));
                finish();
            }
        });

    }


    public void process(View view) {

        String numbers=HPnum.getText().toString().trim();
        String nameofcontacts=contactname.getText().toString().trim();

        Contact obj = new Contact(numbers,nameofcontacts);

        FirebaseDatabase data = FirebaseDatabase.getInstance();
        DatabaseReference node1  = data.getReference("Contacts Driver");

        node1.child(nameofcontacts).setValue(obj);

        HPnum.setText("");
        contactname.setText("");

        Toast.makeText(getApplicationContext(),"Value inserted",Toast.LENGTH_SHORT).show();


    }


}
