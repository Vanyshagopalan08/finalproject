package com.example.psm;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.Map;

public class Profile_Relation extends AppCompatActivity {
    public static final String TAG = "TAG";
    EditText profileFullNameR,profileEmailR,profilePhoneR;
    ImageView profileImageViewR;
    Button saveBtnR, backbtnR;
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    FirebaseUser userRelation;
    StorageReference storageReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile__relation);

        Intent data = getIntent();
        final String fullNameRee = data.getStringExtra("fullName");
        String emailRee = data.getStringExtra("email");
        String phoneRee = data.getStringExtra("phone");

        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        userRelation = fAuth.getCurrentUser();
        storageReference = FirebaseStorage.getInstance().getReference();

        profileFullNameR = findViewById(R.id.editTextTextPersonName);
        profileEmailR = findViewById(R.id.editTextTextEmailAddress);
        profilePhoneR = findViewById(R.id.editTextPhone3);
        profileImageViewR = findViewById(R.id.imageView4);
        saveBtnR = findViewById(R.id.button16);
        backbtnR = findViewById(R.id.button17);

        setTitle("Add Profile Data");

        StorageReference profileRef = storageReference.child("Relation users/"+fAuth.getCurrentUser().getUid()+"/profile.jpg");
        profileRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Picasso.with(Profile_Relation.this).load(uri).into(profileImageViewR);
            }
        });

        profileImageViewR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent openGalleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(openGalleryIntent,1000);
            }
        });

        backbtnR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Profilesetup_Relation.class));
            }
        });

        saveBtnR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(profileFullNameR.getText().toString().isEmpty() || profileEmailR.getText().toString().isEmpty() || profilePhoneR.getText().toString().isEmpty()){
                    Toast.makeText(Profile_Relation.this, "One or Many fields are empty.", Toast.LENGTH_SHORT).show();
                    return;
                }

                final String emailRee = profileEmailR.getText().toString();
                userRelation.updateEmail(emailRee).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        DocumentReference docRef = fStore.collection("Relation users").document(userRelation.getUid());
                        Map<String,Object> edited = new HashMap<>();
                        edited.put("email",emailRee);
                        edited.put("fName",profileFullNameR.getText().toString());
                        edited.put("phone",profilePhoneR.getText().toString());
                        docRef.update(edited).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(Profile_Relation.this, "Profile Updated", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(getApplicationContext(),Profilesetup_Relation.class));
                                finish();
                            }
                        });
                        Toast.makeText(Profile_Relation.this, "Email is changed.", Toast.LENGTH_SHORT).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Profile_Relation.this,   e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });


            }
        });

        profileEmailR.setText(emailRee);
        profileFullNameR.setText(fullNameRee);
        profilePhoneR.setText(phoneRee);

        Log.d(TAG, "onCreate: " + fullNameRee + " " + emailRee + " " + phoneRee);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @androidx.annotation.Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1000){
            if(resultCode == Activity.RESULT_OK){
                Uri imageUri = data.getData();

                //profileImage.setImageURI(imageUri);

                uploadImageToFirebase(imageUri);


            }
        }

    }

    private void uploadImageToFirebase(Uri imageUri) {
        // uplaod image to firebase storage
        final StorageReference fileRef = storageReference.child("Relation users/"+fAuth.getCurrentUser().getUid()+"/profile.jpg");
        fileRef.putFile(imageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                fileRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        Picasso.with(Profile_Relation.this).load(uri).into(profileImageViewR);
                    }
                });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), "Failed.", Toast.LENGTH_SHORT).show();
            }
        });

        Picasso.Builder builder = new Picasso.Builder(getApplicationContext());
        builder.listener(new Picasso.Listener() {
            @Override
            public void onImageLoadFailed(Picasso picasso, Uri uri, Exception exception) {
                exception.printStackTrace();
            }

        });

    }
}