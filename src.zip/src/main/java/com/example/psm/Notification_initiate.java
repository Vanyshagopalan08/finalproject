package com.example.psm;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.pusher.pushnotifications.PushNotifications;

import javax.net.ssl.SSLEngineResult;

public class Notification_initiate extends AppCompatActivity {
    private TextView text1, text2,text3, text4, text5;
    private ImageView safeemo;
    private Button cancel;
    DatabaseReference dref;
    String status,degree, read;
    int data = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_initiate);
        safeemo = findViewById(R.id.imageView7);
        cancel = findViewById(R.id.button4);
        text1 = findViewById(R.id.textView13);
        text2 = findViewById(R.id.textView9);
        text3 = findViewById(R.id.textView);
        text4 = findViewById(R.id.textView2);
        text5 = findViewById(R.id.textView6);

        setTitle("Readings from Sensors");

        PushNotifications.start(getApplicationContext(), "1d373732-be7b-43bc-a5e1-1d9f5a99d5fc");
        PushNotifications.addDeviceInterest("hello");

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Login.class));
            }
        });

        dref = FirebaseDatabase.getInstance().getReference();
        dref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                status=snapshot.child("Data").getValue().toString();
                text1.setText(status);
                degree=snapshot.child("temp").getValue().toString();
                text5.setText(degree);
            }



            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

       /* text1.setOnClickListener(new View.OnClickListener() {
            String read = "data";
            @Override
            public void onClick(View v) {
                if (read < 400) {
                    Toast.makeText(Notification_initiate.this, "Alert!!", Toast.LENGTH_SHORT).show();
                } else {
                    PushNotifications.start(getApplicationContext(), "1d373732-be7b-43bc-a5e1-1d9f5a99d5fc");
                    PushNotifications.addDeviceInterest("Alert gas leaking");
                }
            }
        });


*/



    }
}