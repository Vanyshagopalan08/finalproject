package com.example.psm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Usertype extends AppCompatActivity {
    private ImageView img;
    private Button driver, relation;
    private TextView welcome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usertype);

        welcome = findViewById(R.id.textView14);
        driver = findViewById(R.id.button11);
        relation = findViewById(R.id.button12);
        img = findViewById(R.id.imageView5);

        setTitle("Welcome to Safety App");

        driver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
            }
        });

        relation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Mainpage_Relation.class));
            }
        });
    }

}