package com.example.psm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Notification_Relation extends AppCompatActivity {
    private Button call, loc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification__relation);

        call = findViewById(R.id.button6);
        loc = findViewById(R.id.button5);


        loc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Notification_Relation.this, "Location is tracked", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), TrackerLocation.class));
            }
        });


        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Notification_Relation.this, "Emergency call", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), EmergencyContact_Relation.class));
            }
        });
    }
}