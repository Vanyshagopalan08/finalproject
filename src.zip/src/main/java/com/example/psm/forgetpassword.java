package com.example.psm;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class forgetpassword extends AppCompatActivity {
    private Button emailtoemail;
    private TextView title;
    private EditText enteremail;
    private FirebaseAuth fAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgetpassword);

        setTitle("Forgot Password");

        emailtoemail = findViewById(R.id.passemail);
        title = findViewById(R.id.forgotpasswe);
        enteremail = findViewById(R.id.recemail);
        fAuth = FirebaseAuth.getInstance();

        emailtoemail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailpass = enteremail.getText().toString();
                if(TextUtils.isEmpty(emailpass))
                {
                    Toast.makeText(forgetpassword.this, "please enter correct email", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    fAuth.sendPasswordResetEmail(emailpass).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful())
                            {
                                Toast.makeText(forgetpassword.this, "please visit your email", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(forgetpassword.this, Login.class));
                            }
                            else
                            {
                                String message1 = task.getException().getMessage();
                                Toast.makeText(forgetpassword.this, "Error"+message1, Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });


    }
}