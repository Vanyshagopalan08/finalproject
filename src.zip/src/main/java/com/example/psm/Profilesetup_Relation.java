package com.example.psm;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

public class Profilesetup_Relation extends AppCompatActivity {
    private static final int GALLERY_INTENT_CODE = 1023 ;
    TextView fullNamerelation,emailrelation,phonerelation,verifyMsgrelation;
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    String userIdrelation;
    Button resendCoderelation;
    Button resetPassLocalrelation,changeProfileImagerelation, nextrelation,logoutrelation;
    FirebaseUser userrelation;
    ImageView profileImagerelation;
    StorageReference storageReference;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profilesetup__relation);

        phonerelation = findViewById(R.id.textView20);
        fullNamerelation = findViewById(R.id.textView16);
        emailrelation    = findViewById(R.id.textView18);
        resetPassLocalrelation = findViewById(R.id.button20);
        nextrelation = findViewById(R.id.button21);
        logoutrelation = findViewById(R.id.button22);
        profileImagerelation = findViewById(R.id.profileImageRee);
        changeProfileImagerelation = findViewById(R.id.button19);

        setTitle("Your Profile");

        nextrelation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Notification_Relation.class));
            }
        });


        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        storageReference = FirebaseStorage.getInstance().getReference();

        StorageReference profileRefre = storageReference.child("Relation users/"+fAuth.getCurrentUser().getUid()+"/profile.jpg");
        profileRefre.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Picasso.with(Profilesetup_Relation.this).load(uri).into(profileImagerelation);
            }
        });

        resendCoderelation = findViewById(R.id.button18);
        verifyMsgrelation = findViewById(R.id.textView21);


        userIdrelation = fAuth.getCurrentUser().getUid();
        userrelation = fAuth.getCurrentUser();

        if(!userrelation.isEmailVerified()){
            verifyMsgrelation.setVisibility(View.VISIBLE);
            resendCoderelation.setVisibility(View.VISIBLE);

            resendCoderelation.setOnClickListener(v -> userrelation.sendEmailVerification().addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    Toast.makeText(v.getContext(), "Verification Email Has been Sent.", Toast.LENGTH_SHORT).show();
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.d("tag", "onFailure: Email not sent " + e.getMessage());
                }
            }));
        }

        DocumentReference documentReference = fStore.collection("Relation users").document(userIdrelation);
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {
                if(documentSnapshot.exists()){
                    phonerelation.setText(documentSnapshot.getString("phone"));
                    fullNamerelation.setText(documentSnapshot.getString("fName"));
                    emailrelation.setText(documentSnapshot.getString("email"));

                }else {
                    Log.d("tag", "onEvent: Document do not exists");
                }
            }
        });


        resetPassLocalrelation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final EditText resetPasswordre = new EditText(v.getContext());

                final AlertDialog.Builder passwordResetDialogre = new AlertDialog.Builder(v.getContext());
                passwordResetDialogre.setTitle("Reset Password ?");
                passwordResetDialogre.setMessage("Enter New Password > 6 Characters long.");
                passwordResetDialogre.setView(resetPasswordre);

                passwordResetDialogre.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // extract the email and send reset link
                        String newPasswordre = resetPasswordre.getText().toString();
                        userrelation.updatePassword(newPasswordre).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(Profilesetup_Relation.this, "Password Reset Successfully.", Toast.LENGTH_SHORT).show();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(Profilesetup_Relation.this, "Password Reset Failed.", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });

                passwordResetDialogre.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // close
                    }
                });

                passwordResetDialogre.create().show();

            }
        });

        changeProfileImagerelation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // open gallery
                Intent i = new Intent(v.getContext(),Profile_Relation.class);
                i.putExtra("fullName",fullNamerelation.getText().toString());
                i.putExtra("email",emailrelation.getText().toString());
                i.putExtra("phone",phonerelation.getText().toString());
                startActivity(i);
//

            }
        });

        logoutrelation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();//logout
                startActivity(new Intent(getApplicationContext(),Login_Relation.class));
                finish();

            }
        });



    }
}